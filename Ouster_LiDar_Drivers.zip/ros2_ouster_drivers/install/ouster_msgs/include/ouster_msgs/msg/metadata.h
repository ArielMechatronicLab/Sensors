// generated from rosidl_generator_c/resource/idl.h.em
// with input from ouster_msgs:msg/Metadata.idl
// generated code does not contain a copyright notice

#ifndef OUSTER_MSGS__MSG__METADATA_H_
#define OUSTER_MSGS__MSG__METADATA_H_

#include "ouster_msgs/msg/detail/metadata__struct.h"
#include "ouster_msgs/msg/detail/metadata__functions.h"
#include "ouster_msgs/msg/detail/metadata__type_support.h"

#endif  // OUSTER_MSGS__MSG__METADATA_H_
