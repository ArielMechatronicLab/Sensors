// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef OUSTER_MSGS__MSG__METADATA_HPP_
#define OUSTER_MSGS__MSG__METADATA_HPP_

#include "ouster_msgs/msg/detail/metadata__struct.hpp"
#include "ouster_msgs/msg/detail/metadata__builder.hpp"
#include "ouster_msgs/msg/detail/metadata__traits.hpp"

#endif  // OUSTER_MSGS__MSG__METADATA_HPP_
