// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef OUSTER_MSGS__SRV__GET_METADATA_HPP_
#define OUSTER_MSGS__SRV__GET_METADATA_HPP_

#include "ouster_msgs/srv/detail/get_metadata__struct.hpp"
#include "ouster_msgs/srv/detail/get_metadata__builder.hpp"
#include "ouster_msgs/srv/detail/get_metadata__traits.hpp"

#endif  // OUSTER_MSGS__SRV__GET_METADATA_HPP_
