// generated from rosidl_generator_c/resource/idl.h.em
// with input from ouster_msgs:srv/GetMetadata.idl
// generated code does not contain a copyright notice

#ifndef OUSTER_MSGS__SRV__GET_METADATA_H_
#define OUSTER_MSGS__SRV__GET_METADATA_H_

#include "ouster_msgs/srv/detail/get_metadata__struct.h"
#include "ouster_msgs/srv/detail/get_metadata__functions.h"
#include "ouster_msgs/srv/detail/get_metadata__type_support.h"

#endif  // OUSTER_MSGS__SRV__GET_METADATA_H_
